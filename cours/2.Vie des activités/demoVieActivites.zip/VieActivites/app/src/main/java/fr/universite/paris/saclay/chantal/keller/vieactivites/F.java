package fr.universite.paris.saclay.chantal.keller.vieactivites;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class F extends AppCompatActivity implements View.OnClickListener {

    // Clés pour stocker des valeurs dans l'intention lançant S
    public final static String CLE_L = "CLE_L";
    public final static String CLE_R = "CLE_R";
    // Clé pour sauvegarder le résultat
    public final static String CLE_SAVE = "CLE_SAVE";

    private EditText l, r;
    private Button addition;
    private TextView t;
    private int res = 0;

    // Action à effectuer lorsque l'activité S termine
    private ActivityResultLauncher<Intent> launcher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {
                                Intent intent = result.getData();
                                res = intent.getIntExtra(S.CLE_RES, 0);
                                t.setText(String.valueOf(res));
                            }
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_f);

        l = findViewById(R.id.l);
        r = findViewById(R.id.r);
        addition = findViewById(R.id.addition);
        t = findViewById(R.id.t);

        addition.setOnClickListener(this);

        // Persistance courte : récupération de la sauvegarde et affichage
        if (savedInstanceState != null){
            res = savedInstanceState.getInt(CLE_SAVE);
            t.setText(String.valueOf(res));
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.addition) {
            // Création de l'intention et stockage des valeurs
            Intent intent = new Intent(this, S.class);
            int ll = Integer.parseInt(l.getText().toString());
            int rr = Integer.parseInt(r.getText().toString());
            intent.putExtra(CLE_L, ll);
            intent.putExtra(CLE_R, rr);
            // Lancement de l'activité S sans attendre de résultat
//            startActivity(intent);
            // Lancement de l'activité S en attendant un résultat à traiter
            launcher.launch(intent);
        }
    }

    // Persistance courte : sauvegarde du résultat
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(CLE_SAVE, res);
    }
}