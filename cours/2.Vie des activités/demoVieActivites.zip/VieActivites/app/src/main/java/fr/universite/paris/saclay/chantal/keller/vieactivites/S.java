package fr.universite.paris.saclay.chantal.keller.vieactivites;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class S extends AppCompatActivity {

    // Clé pour stocker une valeur dans l'intention de retour à F
    public final static String CLE_RES = "CLE_RES";

    TextView t;
    int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s);

        t = findViewById(R.id.t);

        // Récupération de l'intention qui a lancé et S et calcul et affichage du résultat
        Intent intent = getIntent();
        int ll = intent.getIntExtra(F.CLE_L, 0);
        int rr = intent.getIntExtra(F.CLE_R, 0);
        res = ll + rr;
        t.setText(String.valueOf(res));
    }

    // Résultat renvoyé lorsque l'activité termine
    @Override
    public void finish() {
        Intent intent = new Intent();
        intent.putExtra(CLE_RES, res);
        setResult(RESULT_OK, intent);
        super.finish();
    }
}