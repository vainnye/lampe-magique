package fr.universite.paris.saclay.chantal.keller.mcc;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.universite.paris.saclay.chantal.keller.mcc.titlePlaceHolder.TitleContent;
import fr.universite.paris.saclay.chantal.keller.mcc.databinding.FragmentTitlesBinding;

// Gestion de la liste de titres
public class TitleRecyclerViewAdapter extends RecyclerView.Adapter<TitleRecyclerViewAdapter.ViewHolder> {

    // Liste des titres
    private final List<TitleContent.TitleItem> mValues;

    // Activité dans laquelle sera contenue cette liste
    private final MCCActivity MCCActivity;

    // Constructeur
    public TitleRecyclerViewAdapter(List<TitleContent.TitleItem> items, MCCActivity na) {
        mValues = items;
        MCCActivity = na;
    }

    // Affichage
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(FragmentTitlesBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    // Création de la vue, et écouteur sur le champ de texte
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.mContentView.setText(mValues.get(position).title);
        holder.setOnClickListener();
    }

    // Méthode obligatoire renvoyant le nombre d'éléments de la liste
    @Override
    public int getItemCount() {
        return mValues.size();
    }

    // Classe représentant la vue pour un item
    public class ViewHolder extends RecyclerView.ViewHolder {
        // La zone de texte
        public final TextView mContentView;
        // L'item correspondant
        public TitleContent.TitleItem mItem;

        // Constructeur
        public ViewHolder(FragmentTitlesBinding binding) {
            super(binding.getRoot());
            // On initialise la zone de texte à l'aide de son identifiant dans le XML
            mContentView = binding.titleItem;
        }

        // Conversion en chaîne de caractères
        @NonNull
        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }

        // Écouteur sur un item
        public void setOnClickListener() {
            mContentView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String text = mItem.title + "\n\n" + mItem.details;
                    MCCActivity.setDetails(text);
                }
            });
        }
    }
}