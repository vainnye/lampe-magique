package fr.universite.paris.saclay.chantal.keller.mcc;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import android.content.SharedPreferences;

public class MCCActivity extends AppCompatActivity {

    // Gestionnaire de fragments
    private FragmentManager fragmentManager;

    // Titre de l'appli
    private TextView appTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mcc);
        appTitle = findViewById(R.id.appTitle);

        // Initialisation du gestionnaire de fragments
        fragmentManager = getSupportFragmentManager();

        // Récupération du fragment attaché sur fragTitles
        Fragment fragment = fragmentManager.findFragmentById(R.id.fragTitles);

        // S'il n'y en a pas : c'est le premier lancement de l'application
        if (fragment == null) {
            TitlesFragment titlesFragment = new TitlesFragment();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.add(R.id.fragTitles, titlesFragment);
            transaction.commit();
        } else {
            // S'il y en a un, mais qui est de type NewsFragment, alors qu'on a de la place pour le
            // mettre sur fragNews, on le met sur fragNews
            if (fragment instanceof DetailsFragment && findViewById(R.id.fragDetails) != null) {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                TitlesFragment titlesFragment = new TitlesFragment();
                transaction.replace(R.id.fragTitles, titlesFragment);
                DetailsFragment detailsFragmentOld = (DetailsFragment) fragment;
                DetailsFragment detailsFragment = DetailsFragment.newInstance(detailsFragmentOld.getDetails());
                transaction.replace(R.id.fragDetails, detailsFragment);
                transaction.commit();
            }
        }
    }

    // Méthode appliquant toutes les préférences
    protected void applyPrefs() {
        // - récupérer les valeurs choisies par l’utilisateurice
        SharedPreferences sharedPref =
                PreferenceManager.getDefaultSharedPreferences(this);
        boolean redTitle = sharedPref.getBoolean("RED_TITLE", false);
        String titleValue = sharedPref.getString("TITLE_VALUE", getString(R.string.mcc));
        // - les appliquer
        int colorId = redTitle ? R.color.red : R.color.black;
        appTitle.setTextColor(getColor(colorId));
        appTitle.setText(titleValue);

        // Aussi sur le fragment avec les détails
        Fragment fragment = fragmentManager.findFragmentById(R.id.fragDetails);
        if (fragment != null) {
            DetailsFragment detailsFragment = (DetailsFragment) fragment;
            detailsFragment.applyPrefs();
        }
    }

    // Application des préférences lorsque l'application devient visible
    @Override
    public void onResume() {
        super.onResume();
        applyPrefs();
    }

    // Mise en place du fragment avec les détails
    protected void setDetails(String text) {
        // Création du fragment
        DetailsFragment detailsFragment = DetailsFragment.newInstance(text);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        int id;
        if (findViewById(R.id.fragDetails) != null) {
            // Placement du fragment sur fragNews si possible...
            id = R.id.fragDetails;
        } else {
            // ... sinon, sur fragTitles, en offrant la possibilité de revenir en arrière
            transaction.addToBackStack("Title");
            id = R.id.fragTitles;
        }
        transaction.replace(id, detailsFragment);
        transaction.commit();
    }

    // Création du menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    // Écouteur sur le menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // L’item sur lequel l’utilisateurice a cliqué
        int id = item.getItemId();
        // Action choisie selon l’item
        if (id == R.id.settings) {
            // Attachement du fragment de préférences
            SettingsFragment settingsFragment = new SettingsFragment();
            fragmentManager.beginTransaction().addToBackStack("pref")
                    .replace(R.id.fragTitles, settingsFragment).commit();
            return true;
        }
        if (id == R.id.init_settings) {
            initPref();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Réinitialisation des préférences
    private void initPref() {
        // Réinitialisation de la sauvegarde
        PreferenceManager.getDefaultSharedPreferences(this).edit().clear().apply();
        // Lecture des valeurs par défaut
        PreferenceManager.setDefaultValues(this, R.xml.root_preferences, true);
        // Les appliquer !
        applyPrefs();
    }
}