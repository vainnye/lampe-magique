package fr.universite.paris.saclay.chantal.keller.mcc;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.PreferenceManager;

// Fragment affichant le contenu de la news
public class DetailsFragment extends Fragment {

    // Clé pour le contenu
    public final static String ARG_CONTENT = "ARG_CONTENT";

    // Contenu
    private String details;
    TextView detailsTextView;

    // Constructeur vide obligatoire pour les fragments
    public DetailsFragment() {}

    // Construction d'un fragment avec son contenu
    public static DetailsFragment newInstance(String content) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_CONTENT, content);
        fragment.setArguments(args);
        return fragment;
    }

    // Récupération du contenu au moment de la création du fragment
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            details = getArguments().getString(ARG_CONTENT);
        }
    }

    // Afichage du fragment, avec son contenu
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_details, container, false);
        detailsTextView = v.findViewById(R.id.details);
        detailsTextView.setText(this.details);
        return v;
    }

    // Méthode appliquant toutes les préférences
    protected void applyPrefs() {
        // - récupérer les valeurs choisies par l’utilisateurice
        SharedPreferences sharedPref =
                PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean largeText = sharedPref.getBoolean("LARGE_TEXT", true);
        // - les appliquer
        detailsTextView.setTextSize(largeText ? 20 : 10);
    }

    // Application des préférences lorsque l'application devient visible
    @Override
    public void onResume() {
        super.onResume();
        applyPrefs();
    }

    // Récupération du contenu
    protected String getDetails() {
        return details;
    }
}