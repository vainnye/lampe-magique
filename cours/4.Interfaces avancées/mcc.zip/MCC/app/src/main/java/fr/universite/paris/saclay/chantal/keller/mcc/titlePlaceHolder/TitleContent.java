package fr.universite.paris.saclay.chantal.keller.mcc.titlePlaceHolder;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;

// Contenu des titres
public class TitleContent {

    // Tableau de titres
    public static final List<TitleItem> ITEMS = new ArrayList<TitleItem>();

    // Dans cette démo, on remplit la liste de façon statique. De manière plus générale, on irait
    // probablement chercher les informations sur internet.
    static {
        addItem(new TitleItem("R401/2 - Architecture logicielle et qualité de développement", "- contrôle dans chaque matière\n- modélication UML du projet\n- TP noté en qualité\n- évaluation finale de 2h"));
        addItem(new TitleItem("R403 - Introduction au web sémantique", "2 évaluations sur Moodle"));
        addItem(new TitleItem("R404 - Méthodes d'optimisation", "2 évaluations"));
        addItem(new TitleItem("R405 - Anglais", "2 évaluations"));
        addItem(new TitleItem("R406 - Communication interne", "- TP\n- rendu final"));
        addItem(new TitleItem("R407 - PPP", "- entretien\n- rédaction"));
        addItem(new TitleItem("R4A08 - Virtualisation", "- TP noté\n- évaluation finale"));
        addItem(new TitleItem("R409 - Management avancé des SI", "- quizz\n- exposé\n- évaluation finale sur Moodle"));
        addItem(new TitleItem("R4A10 - Complément web", "- CC\n- questions de cours\n- évaluation finale sur machine"));
        addItem(new TitleItem("R4A11 - Développement Android", "- projet\n- TP noté\n- évaluation finale sur Moodle"));
        addItem(new TitleItem("R4A12 - Automates", "- évaluation en TD\n- évaluation finale"));
        addItem(new TitleItem("R4A20 - Marketing", "- contrôle continu\n- évaluation finale"));
        addItem(new TitleItem("R4A21 - Maths pour l'ingé", "2 évaluations"));
        addItem(new TitleItem("S4A01 - Projet", "- travail écrit\n- travail oral\n- réalisation/démo\n- évaluation par les pairs"));
    }

    // Ajout d'un titre dans le tableau
    private static void addItem(TitleItem item) {
        ITEMS.add(item);
    }

    // Classe représentant un titre
    public static class TitleItem {
        public final String title;
        public final String details;

        public TitleItem(String t, String d) {
            title = t;
            details = d;
        }

        // Conversion textuelle
        @NonNull
        @Override
        public String toString() {
            return title;
        }
    }
}
