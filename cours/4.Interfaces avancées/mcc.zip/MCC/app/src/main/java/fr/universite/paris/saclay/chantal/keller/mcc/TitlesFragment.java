package fr.universite.paris.saclay.chantal.keller.mcc;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import fr.universite.paris.saclay.chantal.keller.mcc.titlePlaceHolder.TitleContent;


public class TitlesFragment extends Fragment {

    // Constructeur vide obligatoire
    public TitlesFragment() { }

    // Création de la vue
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_titles_list, container, false);

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            MCCActivity MCCActivity = (MCCActivity) getActivity();
            recyclerView.setAdapter(new TitleRecyclerViewAdapter(TitleContent.ITEMS, MCCActivity));
        }
        return view;
    }
}