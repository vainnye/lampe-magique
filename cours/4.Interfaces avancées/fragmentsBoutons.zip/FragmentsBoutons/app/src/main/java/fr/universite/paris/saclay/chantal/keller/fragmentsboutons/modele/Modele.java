package fr.universite.paris.saclay.chantal.keller.fragmentsboutons.modele;

import android.os.Bundle;

import java.util.ArrayList;

// Modèle stockant le nombre de clics effectués sur chaque fragment
public class Modele {
    private static ArrayList<Integer> nbClics = new ArrayList<>();
    public static final String SAVE_NB_CLICS = "SAVE_NB_CLICS";

    public static void init() {
        nbClics.add(0);
        nbClics.add(0);
    }

    public static void create() {
        nbClics.add(0);
    }

    public static int getNbClics(int i) {
        return nbClics.get(i);
    }

    public static void incNbClics(int i) {
        nbClics.set(i, nbClics.get(i) + 1);
    }

    public static int nbFrags() {
        return nbClics.size();
    }

    public static void save(Bundle bundle) {
        bundle.putIntegerArrayList(SAVE_NB_CLICS, nbClics);
    }

    public static void restore(Bundle bundle) {
        nbClics = bundle.getIntegerArrayList(SAVE_NB_CLICS);
    }

}
