package fr.universite.paris.saclay.chantal.keller.fragmentsboutons;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import fr.universite.paris.saclay.chantal.keller.fragmentsboutons.modele.Modele;

// Classe gérant les fragments
// Partage de code : une seule classe !
public class ButtonFragment extends Fragment implements View.OnClickListener {
    // Zone d'affichage
    private TextView tv;
    // Numéro du fragment
    public int fragNum = 0;

    // Clé pour la création de fragments
    private static final String ARG_FRAG_NUM = "ARG_FRAG_NUM";

    public ButtonFragment() {
        // Required empty public constructor
    }

    // Création d'un nouveau fragment
    public static ButtonFragment newInstance(int fn) {
        ButtonFragment fragment = new ButtonFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_FRAG_NUM, fn);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            fragNum = getArguments().getInt(ARG_FRAG_NUM);
        }
    }

    // Méthode principale gérant la création du fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_button, container, false);
        // Écouteur sur le bouton
        Button bt_inc = v.findViewById(R.id.button_frag);
        bt_inc.setText("frag"+fragNum+"++");
        bt_inc.setOnClickListener(this);
        // Zone d'affichage
        tv = v.findViewById( R.id.textview_frag);
        update_textview();
        // On renvoie la vue
        return v;
    }

    // Écouteur
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button_frag) {
            Modele.incNbClics(fragNum);
            update_textview();
        }
    }

    // Mise à jour de l'affichage
    private void update_textview(){
        tv.setText("frag"+fragNum+" : "+ Modele.getNbClics(fragNum));
    }
}