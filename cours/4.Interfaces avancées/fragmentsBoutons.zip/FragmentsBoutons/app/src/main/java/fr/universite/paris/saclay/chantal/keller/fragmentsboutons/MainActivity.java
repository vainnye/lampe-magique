package fr.universite.paris.saclay.chantal.keller.fragmentsboutons;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import fr.universite.paris.saclay.chantal.keller.fragmentsboutons.modele.Modele;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Tableau de tous les fragments créés
    private final ArrayList<ButtonFragment> frags = new ArrayList<>();
    // Informations concernant le fragment attaché à gauche et celui attaché à droite
    private FragInfo fi0, fi1;
    // Clés pour la persistance courte
    private final static String SAVE_FRAG_NUM_0 = "SAVE_FRAG_NUM_0";
    private final static String SAVE_FRAG_NUM_1 = "SAVE_FRAG_NUM_1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Écouteurs sur les boutons
        Button button_chg0 = findViewById(R.id.button_chg0);
        Button button_crea0 = findViewById(R.id.button_crea0);
        Button button_chg1 = findViewById(R.id.button_chg1);
        Button button_crea1 = findViewById(R.id.button_crea1);
        button_chg0.setOnClickListener(this);
        button_crea0.setOnClickListener(this);
        button_chg1.setOnClickListener(this);
        button_crea1.setOnClickListener(this);
        if (savedInstanceState == null) {
            // Actions à effectuer à la première création de l'activité
            // Initalisation du modèle, des 2 fragments et de leurs infos
            Modele.init();
            fi0 = new FragInfo(0, R.id.fragment0);
            fi1 = new FragInfo(1, R.id.fragment1);
            frags.add(ButtonFragment.newInstance(0));
            frags.add(ButtonFragment.newInstance(1));
            // Affichage des deux fragments
            FragmentTransaction transaction_init = getSupportFragmentManager().beginTransaction();
            transaction_init.add(fi0.fragId, frags.get(0));
            transaction_init.add(fi1.fragId, frags.get(1));
            transaction_init.commit();
        } else {
            // Actions à effectuer après rotation de la tablette
            // Récupération des données sauvegardées
            Modele.restore(savedInstanceState);
            int fn0 = savedInstanceState.getInt(SAVE_FRAG_NUM_0);
            int fn1 = savedInstanceState.getInt(SAVE_FRAG_NUM_1);
            // Infos sur les deux fragments attachés
            fi0 = new FragInfo(fn0, R.id.fragment0);
            fi1 = new FragInfo(fn1, R.id.fragment1);
            // Re-création de tous les fragments
            for (int i = 0; i < Modele.nbFrags(); i++) {
                frags.add(ButtonFragment.newInstance(i));
            }
            // Affichage des deux fragments
            FragmentTransaction transaction_init = getSupportFragmentManager().beginTransaction();
            transaction_init.replace(fi0.fragId, frags.get(fn0));
            transaction_init.replace(fi1.fragId, frags.get(fn1));
            transaction_init.commit();
        }
    }

    // Écouteur
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button_chg0) {
            fi0.change(fi1);
        } else if (view.getId() == R.id.button_chg1) {
            fi1.change(fi0);
        } else if (view.getId() == R.id.button_crea0) {
            fi0.create();
        } else if (view.getId() == R.id.button_crea1) {
            fi1.create();
        }
    }

    // Infos sur les deux emplacements de fragments
    private class FragInfo {
        // Numéro du fragment attaché
        private int fragNum;
        // Identifiant de l'emplacement
        private final int fragId;

        public FragInfo(int fn, int fi) {
            fragNum = fn;
            fragId = fi;
        }

        // Passage d'un fragment au suivant, en "sautant" un fragment s'il est déjà affiché de
        // l'autre côté
        public void change(FragInfo fi) {
            fragNum = (fragNum+1)%Modele.nbFrags();
            if (fragNum == fi.fragNum) {
                fragNum = (fragNum+1)%Modele.nbFrags();
            }
            FragmentTransaction transaction_init = getSupportFragmentManager().beginTransaction();
            transaction_init.replace(fragId, frags.get(fragNum));
            transaction_init.commit();
        }

        // Création et attachement d'un nouveau fragment
        public void create() {
            Modele.create();
            int num = Modele.nbFrags()-1;
            fragNum = num;
            frags.add(ButtonFragment.newInstance(num));
            FragmentTransaction transaction_init = getSupportFragmentManager().beginTransaction();
            transaction_init.replace(fragId, frags.get(num));
            transaction_init.commit();
        }
    }

    // Persistance courte
    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        Modele.save(bundle);
        bundle.putInt(SAVE_FRAG_NUM_0, fi0.fragNum);
        bundle.putInt(SAVE_FRAG_NUM_1, fi1.fragNum);
    }
}