package fr.universite.paris.saclay.chantal.keller.demopreferences;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class LoremFragment extends Fragment {

    TextView core;

    public LoremFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View res = inflater.inflate(R.layout.fragment_lorem, container, false);

        // Récupération des objets de l'interface
        core = res.findViewById(R.id.core);
        return res;
    }

    // Application des préférences lorsque le fragment devient visible
    @Override
    public void onResume() {
        super.onResume();

        // - récupérer les valeurs choisies par l'utilisateurice
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean largeText = sharedPref.getBoolean(String.valueOf(getResources().getText(R.string.LARGE_TEXT)), false);

        // - les appliquer
        setLargeText(largeText);
    }

    protected void setLargeText(boolean largeText) {
        core.setTextSize(largeText ? 40 : 20);
    }
}