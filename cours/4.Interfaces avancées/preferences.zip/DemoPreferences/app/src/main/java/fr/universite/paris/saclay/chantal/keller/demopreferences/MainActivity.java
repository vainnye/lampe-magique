package fr.universite.paris.saclay.chantal.keller.demopreferences;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView title;

    LoremFragment loremFrag = new LoremFragment();
    PrefFragment prefFrag = new PrefFragment();

    // Gestionnaire de fragments
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialisation du gestionnaire de fragments
        fragmentManager = getSupportFragmentManager();

        // Récupération des objets de l'interface
        title = findViewById(R.id.title);

        // Attachement du fragment "lorem ipsum" si premier lancement de l'activité
        if (!loremFrag.isAdded()) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.add(R.id.frag, loremFrag);
            transaction.commit();
        }

        // Écouteur sur le bouton lançant les préférences
        Button pref = findViewById(R.id.pref);
        pref.setOnClickListener(this);

    }

    // Écouteur
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.pref) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.addToBackStack("pref");
            transaction.replace(R.id.frag, prefFrag);
            transaction.commit();
        }
    }

    // Application des préférences lorsque l'activité devient visible
    @Override
    protected void onResume() {
        super.onResume();

        // - récupérer les valeurs choisies par l'utilisateurice
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean redTitle = sharedPref.getBoolean(String.valueOf(getResources().getText(R.string.RED_TITLE)), true);
        String titleValue = sharedPref.getString(String.valueOf(getResources().getText(R.string.TITLE_VALUE)), String.valueOf(getResources().getText(R.string.lorem_ipsum)));

        // - les appliquer
        setRedTitle(redTitle);
        setTitleValue(titleValue);
    }

    protected void setRedTitle(boolean redTitle) {
        title.setTextColor(redTitle ? Color.RED : Color.BLACK);
    }

    protected void setTitleValue(String titleValue) {
        title.setText(titleValue);
    }
}