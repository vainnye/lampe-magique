package fr.universite.paris.saclay.chantal.keller.demopreferences;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.preference.PreferenceFragmentCompat;

public class PrefFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);
    }

    // Écouteur
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        final MainActivity mainActivity = (MainActivity) getActivity();
        final String RED_TITLE = String.valueOf(getResources().getText(R.string.RED_TITLE));
        final String TITLE_VALUE = String.valueOf(getResources().getText(R.string.TITLE_VALUE));
        if (key.equals(RED_TITLE)) {
            boolean redTitle = sharedPreferences.getBoolean(key, true);
            mainActivity.setRedTitle(redTitle);
        } else if (key.equals(TITLE_VALUE)) {
            String titleValue = sharedPreferences.getString(key, "Lorem ipsum");
            mainActivity.setTitleValue(titleValue);
        }
    }

    // Lancement de l'écouteur
    @Override
    public void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    // Arrêt de l'écouteur
    @Override
    public void onPause() {
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }
}
