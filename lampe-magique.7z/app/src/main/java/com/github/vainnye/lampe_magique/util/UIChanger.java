package com.github.vainnye.lampe_magique.util;

@FunctionalInterface
public interface UIChanger {
    public void changeUI();
}
